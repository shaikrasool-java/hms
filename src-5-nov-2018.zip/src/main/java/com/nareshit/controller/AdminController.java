package com.nareshit.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nareshit.bean.AdminBean;
import com.nareshit.domain.Admin;
import com.nareshit.repository.IAdminRepository;
import com.nareshit.utility.AdminMapper;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private IAdminRepository aRepo;

	@RequestMapping(value="/addAdminPage")
	public String addAdmin(Model model) {
		model.addAttribute("adminBean", new AdminBean());
		return "adminAdd";
	}
	/*@PostMapping(value="/save")
	public AdminBean saveAdmin(@RequestBody AdminBean adminBean) {
		Admin ad=AdminMapper.mapBeanToDomain(adminBean);
		ad=aRepo.save(ad);
		adminBean=AdminMapper.mapDomainToBean(ad);
		return adminBean;
	}*/




	@GetMapping(value="/getAdminBoard")
	public String getAdminBoard(ModelMap map) {
		map.addAttribute("adminBean", new AdminBean());
		Iterator<Admin> adDominList=aRepo.findAll().iterator();
		List<AdminBean> admBeansList=AdminMapper.mapDominListToBean(adDominList);
		map.addAttribute("adList", admBeansList);
		return "adminBoard";
	}

	@PostMapping(value="/addAdmin")
	public String addAdmin(@ModelAttribute("adminBean") AdminBean adminBean, Model model) {

		Admin ad=AdminMapper.mapBeanToDomain(adminBean);
		ad=aRepo.save(ad);
		adminBean=AdminMapper.mapDomainToBean(ad);
		model.addAttribute("adminBean", new AdminBean());

		return "redirect:./getAdminBoard";
	}

	@GetMapping(value="/deleteAdmin/{id}")
	public String deletAdmin(Model model,@PathVariable("id")Integer id) {
		aRepo.delete(id);
		Iterator<Admin> adDominList=aRepo.findAll().iterator();
		List<AdminBean> admBeansList=AdminMapper.mapDominListToBean(adDominList);
		model.addAttribute("adList", admBeansList);
		return "adminBoard";

	}
	@GetMapping(value="/editAdmin/{id}")
	public String editAdmin(Model model, @PathVariable("id")Integer id) {
		Admin ad=aRepo.findOne(id);
		AdminBean adBean=AdminMapper.mapDomainToBean(ad);
		model.addAttribute("adminBean", adBean);
		return "editA";
	}

	@PostMapping(value="/updateAdmin")
	public String updateAdmin(@ModelAttribute("adminBean") AdminBean adminBean) {
		Admin ad=AdminMapper.mapBeanToDomain(adminBean);
		ad=aRepo.save(ad);
		adminBean=AdminMapper.mapDomainToBean(ad);
		return "redirect:./getAdminBoard";
	}

}