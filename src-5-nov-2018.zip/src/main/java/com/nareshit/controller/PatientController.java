package com.nareshit.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nareshit.bean.PatientBean;
import com.nareshit.domain.Patient;
import com.nareshit.repository.IPatientRepository;
import com.nareshit.utility.PatientMapper;

@Controller
@RequestMapping("/patient")
public class PatientController {

	@Autowired
	private IPatientRepository prepo;

	@RequestMapping("/addPatientPage")
	public String addPatient(Model model) {
		model.addAttribute("patBean", new PatientBean());
		return "patAdd";
	}

	@GetMapping(value="/getPatientBoard")
	public String findPatient(Model model) {
		model.addAttribute("patBean", new PatientBean());
		Iterator<Patient> ptDomainList=prepo.findAll().iterator();
		List<PatientBean> ptBeanList=PatientMapper.mapDomainListToBean(ptDomainList);
		model.addAttribute("patientList", ptBeanList);
		return "patBoard";
	}
	@RequestMapping(value="/addPatient")
	public String addPatient(@ModelAttribute("patBean") PatientBean patBean, ModelMap map) {
		Patient pat=PatientMapper.mapBeanToDomain(patBean);
		pat=prepo.save(pat);
		patBean=PatientMapper.mapDomainToBean(pat);
		map.addAttribute("patBean", new PatientBean());
		//			return "addPatient";
		return "redirect:./getPatientBoard";	
	}

/*
	@PostMapping(value="/save")
	public PatientBean savePati(@RequestBody PatientBean patBean) {

		Patient pat=PatientMapper.mapBeanToDomain(patBean);
		pat=prepo.save(pat);
		patBean=PatientMapper.mapDomainToBean(pat);
		return patBean;
	}
*/
	@GetMapping("/deletePt/{id}")
	public String deletePatient(Model model, @PathVariable("id")Integer id) {
		prepo.delete(id);
		Iterator<Patient> ptDomainList=prepo.findAll().iterator();
		List<PatientBean> ptBeanList=PatientMapper.mapDomainListToBean(ptDomainList);
		model.addAttribute("patientList", ptBeanList);
		return "patBoard";
	
	}
	@GetMapping(value="/editPt/{id}")
	public String editPatient(Model model, @PathVariable("id")Integer id) {
		Patient p=prepo.findOne(id);
		PatientBean ptBean=PatientMapper.mapDomainToBean(p);
		model.addAttribute("patBean", ptBean);
		return "editP";
	}
	@PostMapping(value="/updatePatient")
	public String updatePatient(@ModelAttribute("patBean") PatientBean patBean) {
		Patient pt=PatientMapper.mapBeanToDomain(patBean);
		pt=prepo.save(pt);
		patBean=PatientMapper.mapDomainToBean(pt);
		return "redirect:./getPatientBoard";
		}
		
	
}


