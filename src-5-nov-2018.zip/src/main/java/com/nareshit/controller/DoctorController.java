package com.nareshit.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nareshit.bean.DoctorBean;
import com.nareshit.domain.Doctor;
import com.nareshit.repository.IDoctorRepository;
import com.nareshit.utility.DoctorMapper;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

	@Autowired
	private IDoctorRepository drepo;
	
	
	@RequestMapping(value="/addDoctorPage")
	public String addDoctor(Model model) {
			model.addAttribute("docBean", new DoctorBean());
		return "docAdd";
		}
	/*
	@PostMapping(value="/save")
	public DoctorBean saveDoc(@RequestBody DoctorBean drBean) {
		
		Doctor dr=DoctorMapper.mapBeanToDomain(drBean);
		dr=drepo.save(dr);
		drBean=DoctorMapper.mapDomainToBean(dr);
		
		return drBean;
	}*/
	
	
	@GetMapping(value="/getDoctorBoard")
	public String findDoctor(Model model) {
		model.addAttribute("docBean", new DoctorBean());
		Iterator<Doctor> drDomainList=drepo.findAll().iterator();
		List<DoctorBean> drBeanList=DoctorMapper.mapDomainListToBean(drDomainList);
		model.addAttribute("drList", drBeanList);
		return "drBoard";
	}
	@RequestMapping(value="/addDoctor")
	public String addDoctor(@ModelAttribute("docBean") DoctorBean docBean, ModelMap map) {
		Doctor doc=DoctorMapper.mapBeanToDomain(docBean);
		doc=drepo.save(doc);
		docBean=DoctorMapper.mapDomainToBean(doc);
		map.addAttribute("docBean", new DoctorBean());
		String msg="Doctor '"+docBean.getFname()+"' added successfully...";
		map.addAttribute("message", msg);
		
		/*return "addDoctor";*/
		return "redirect:./getDoctorBoard";
	}
	@GetMapping(value="/deleteDr/{id}")
	public String deleteDoctor(Model model, @PathVariable("id")Integer id) {
		drepo.delete(id);
		Iterator<Doctor> drDomainList=drepo.findAll().iterator();
		List<DoctorBean> drBeanList=DoctorMapper.mapDomainListToBean(drDomainList);
		model.addAttribute("drList", drBeanList);
		return "drBoard";
	}
	@GetMapping(value="/editDr/{id}")
	public String editDoctor(Model model, @PathVariable("id")int id) {
		Doctor d=drepo.findOne(id);
		DoctorBean drBean=DoctorMapper.mapDomainToBean(d);
		model.addAttribute("drBean", drBean);
		return "editD";
	}
	
	@PostMapping(value="/updateDoctor")
	public String updateDoctor(@ModelAttribute("drBean") DoctorBean drBean, ModelMap map) {
		
		Doctor dr=DoctorMapper.mapBeanToDomain(drBean);
		dr=drepo.save(dr);
		drBean=DoctorMapper.mapDomainToBean(dr);
		//return "addDoctor"
		return "redirect:./getDoctorBoard";
	}
	
	
}
